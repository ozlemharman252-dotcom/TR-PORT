package com.trport.app

import android.os.Bundle
import android.opengl.GLES20
import android.os.Build
import android.app.ActivityManager
import android.content.Context
import android.view.Display
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.input.key.*
import androidx.compose.ui.window.Dialog
import java.io.File

private val bg = Color(0xFF090D0B)
private val panel = Color(0xFF141B17)
private val green = Color(0xFF4DFF88)
private val muted = Color(0xFF9AA8A0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(9,13,11)
        window.navigationBarColor = android.graphics.Color.rgb(9,13,11)
        setContent { TRPortApp() }
    }
}

@Composable
fun TRPortApp() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("trport", Context.MODE_PRIVATE) }
    var page by remember { mutableStateOf("Ana Sayfa") }
    var scanned by remember { mutableStateOf(false) }
    var lowMode by remember { mutableStateOf(prefs.getBoolean("low", false)) }
    var profile by remember { mutableStateOf(prefs.getString("profile", "OTOMATİK") ?: "OTOMATİK") }
    var fps by remember { mutableStateOf(prefs.getInt("fps", 30)) }
    var resolution by remember { mutableStateOf(prefs.getString("resolution", "Otomatik") ?: "Otomatik") }
    var renderer by remember { mutableStateOf(prefs.getString("renderer", "Otomatik") ?: "Otomatik") }
    var showDevice by remember { mutableStateOf(false) }
    var toast by remember { mutableStateOf("") }
    val device = deviceInfo(ctx)

    fun save() {
        prefs.edit().putBoolean("low", lowMode).putString("profile", profile)
            .putInt("fps", fps).putString("resolution", resolution)
            .putString("renderer", renderer).apply()
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = green, background = bg, surface = panel, onPrimary = Color.Black,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Column(Modifier.fillMaxSize().background(bg)) {
            Header()
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal=16.dp)) {
                when(page) {
                    "Ana Sayfa" -> HomePage(
                        profile, lowMode, scanned, device, onScan={scanned=true;showDevice=true},
                        onOptimize={ profile="PERFORMANS"; fps=30; resolution="640x360"; renderer="Vulkan (varsa)"; lowMode=true; save(); toast="Performans profili uygulandı" },
                        onLow={ lowMode=!lowMode; if(lowMode){profile="DÜŞÜK";fps=20;resolution="480x270"};save()},
                        onMode={ toast="$it seçildi"; page=it }
                    )
                    "Grafik" -> GraphicsPage(profile, {profile=it;save()}, resolution,{resolution=it;save()}, fps,{fps=it;save()},lowMode)
                    "İndirme" -> DownloadPage()
                    "Gamepad" -> GamepadPage()
                    "Ayarlar" -> SettingsPage(renderer,{renderer=it;save()},lowMode,{lowMode=it;save()})
                    else -> HomePage(profile,lowMode,scanned,device,{scanned=true;showDevice=true},{toast="Optimizasyon uygulanması için cihaz bilgisi kontrol edildi";profile="DENGELİ";save()},{lowMode=!lowMode;save()},{toast="$it seçildi"})
                }
                if(toast.isNotBlank()) {
                    Spacer(Modifier.height(8.dp))
                    Text(toast, color=green, fontSize=13.sp)
                }
                Spacer(Modifier.height(16.dp))
            }
            BottomNav(page) { page=it }
        }
        if(showDevice) DeviceDialog(device) { showDevice=false }
    }
}

@Composable
fun Header() {
    Row(Modifier.fillMaxWidth().padding(horizontal=18.dp, vertical=16.dp), verticalAlignment=Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("TR PORT", color=green, fontSize=28.sp, fontWeight=FontWeight.Black, letterSpacing=2.sp)
            Text("ANDROID GAME HUB  •  PREVIEW", color=muted, fontSize=10.sp, letterSpacing=1.sp)
        }
        Box(Modifier.background(Color(0xFF1B2C22), RoundedCornerShape(12.dp)).padding(horizontal=10.dp, vertical=8.dp)) {
            Text("v0.1", color=green, fontWeight=FontWeight.Bold, fontSize=12.sp)
        }
    }
}

@Composable
fun HomePage(profile:String, low:Boolean, scanned:Boolean, device:DeviceData, onScan:()->Unit, onOptimize:()->Unit, onLow:()->Unit, onMode:(String)->Unit) {
    Column(verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Box(Modifier.fillMaxWidth().height(180.dp).background(
            androidx.compose.ui.graphics.Brush.linearGradient(listOf(Color(0xFF173A27),Color(0xFF111916),Color(0xFF080B09))),
            RoundedCornerShape(22.dp)).padding(18.dp), contentAlignment=Alignment.BottomStart) {
            Column {
                Text("MOBILE GAME
COMPANION", color=Color.White, fontSize=24.sp, fontWeight=FontWeight.ExtraBold, lineHeight=27.sp)
                Spacer(Modifier.height(6.dp))
                Text("Oyun deneyimini cihazına göre yapılandır.", color=muted, fontSize=12.sp)
            }
        }
        Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
            ActionCard("STORY MODE", "Oyun çalıştırıcı entegrasyonu gerekli", Modifier.weight(1f)) { onMode("Story Mode") }
            ActionCard("ONLINE MODE", "Resmî Android desteği garanti edilmez", Modifier.weight(1f)) { onMode("Online Mode") }
        }
        Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
            ActionCard("CİHAZI TARA", "Donanım bilgileri", Modifier.weight(1f), onScan)
            ActionCard("OPTİMİZE ET", "Önerilen profil", Modifier.weight(1f), onOptimize)
        }
        Panel {
            Row(verticalAlignment=Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("DÜŞÜK CİHAZ MODU", fontWeight=FontWeight.Bold)
                    Text(if(low) "Aktif • azaltılmış ayarlar" else "Bellek ve grafik yükünü azalt", color=muted, fontSize=12.sp)
                }
                Switch(checked=low, onCheckedChange={onLow()}, colors=SwitchDefaults.colors(checkedThumbColor=Color.Black, checkedTrackColor=green))
            }
        }
        Panel {
            Text("HIZLI AYARLAR", color=green, fontWeight=FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            InfoRow("Aktif profil", profile)
            InfoRow("FPS hedefi", if(low) "20 / 30 FPS" else "30 FPS")
            InfoRow("Çözünürlük", if(low) "480x270" else "Otomatik")
            InfoRow("Render", "Otomatik")
        }
        Panel {
            Text("OYUN DOSYALARI", color=green, fontWeight=FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text("Bu yardımcı uygulama oyun dosyası içermez. Yalnızca sahip olduğun ve lisanslı dosyalarla uyumlu bir çalıştırma ortamı kullanılabilir.", color=muted, fontSize=12.sp)
        }
    }
}

data class DeviceData(val model:String, val android:String, val cores:Int, val ram:String, val screen:String, val refresh:String, val gl:String, val storage:String)
fun deviceInfo(ctx:Context):DeviceData {
    val am=ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val mem=ActivityManager.MemoryInfo(); am.getMemoryInfo(mem)
    val dm=ctx.resources.displayMetrics
    val gl=try { GLES20.glGetString(GLES20.GL_RENDERER) ?: "Bilinmiyor" } catch(e:Exception) { "GL bilgisi uygulama bağlamında alınamadı" }
    val total=mem.totalMem/1024/1024
    val avail=mem.availMem/1024/1024
    val stat=android.os.StatFs(ctx.filesDir.path)
    val free=stat.availableBytes/1024/1024/1024
    return DeviceData(Build.MODEL, "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})", Runtime.getRuntime().availableProcessors(),
        "${avail} MB boş / ${total} MB toplam", "${dm.widthPixels} × ${dm.heightPixels}", "Sistem ekran bilgisi", gl, "${free} GB boş")
}

@Composable
fun DeviceDialog(d:DeviceData, close:()->Unit) {
    AlertDialog(onDismissRequest=close, containerColor=panel, title={Text("CİHAZ BİLGİLERİ",color=green)},
        text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            InfoRow("Model",d.model);InfoRow("Android",d.android);InfoRow("CPU çekirdek",d.cores.toString())
            InfoRow("RAM",d.ram);InfoRow("Ekran",d.screen);InfoRow("Yenileme",d.refresh);InfoRow("GPU",d.gl);InfoRow("Depolama",d.storage)
            Text("Not: GPU/Vulkan, sıcaklık ve FPS ölçümü için gerçek çalışma ortamında ayrı ölçüm katmanı gerekir.",color=muted,fontSize=11.sp)
        }}, confirmButton={TextButton(onClick=close){Text("KAPAT",color=green)}})
}

@Composable
fun GraphicsPage(profile:String, setProfile:(String)->Unit, res:String, setRes:(String)->Unit, fps:Int, setFps:(Int)->Unit, low:Boolean) {
    Column(verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Panel {
            Text("GRAFİK PROFİLİ", color=green, fontWeight=FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            listOf("OTOMATİK","DÜŞÜK","ORTA","YÜKSEK","ULTRA").forEach { p ->
                Row(verticalAlignment=Alignment.CenterVertically) {
                    RadioButton(selected=profile==p,onClick={setProfile(p)}, colors=RadioButtonDefaults.colors(selectedColor=green))
                    Text(p, modifier=Modifier.weight(1f))
                    if(p=="ULTRA") Text("Cihaza bağlı",color=muted,fontSize=10.sp)
                }
            }
        }
        Panel {
            Text("FPS SINIRI",color=green,fontWeight=FontWeight.Bold)
            val options=listOf(20,30,40,60,90,120)
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) {
                options.forEach { f ->
                    FilterChip(selected=fps==f,onClick={setFps(f)},label={Text("$f")}, colors=FilterChipDefaults.filterChipColors(selectedContainerColor=green,selectedLabelColor=Color.Black))
                }
            }
            Text("Seçim hedef sınırıdır. Gerçek FPS, oyun motoru ve cihaz performansına bağlıdır.",color=muted,fontSize=11.sp)
        }
        Panel {
            Text("ÇÖZÜNÜRLÜK",color=green,fontWeight=FontWeight.Bold)
            val resolutions=listOf("Otomatik","480x270","640x360","800x450","960x544","1024x576","1280x720","1600x900","1920x1080","Özel")
            resolutions.forEach { r ->
                Row(verticalAlignment=Alignment.CenterVertically) {
                    RadioButton(selected=res==r,onClick={setRes(r)},colors=RadioButtonDefaults.colors(selectedColor=green))
                    Text(r)
                }
            }
        }
        Panel {
            Text("EK GRAFİK AYARLARI",color=green,fontWeight=FontWeight.Bold)
            SliderRow("Doku kalitesi", if(low) 0.2f else 0.6f)
            SliderRow("Gölge kalitesi", if(low) 0f else 0.4f)
            SliderRow("Yansımalar", if(low) 0f else 0.3f)
            SliderRow("Görüş mesafesi", if(low) 0.25f else 0.5f)
            SliderRow("Efekt kalitesi", if(low) 0.2f else 0.5f)
            SliderRow("Kenar yumuşatma", if(low) 0f else 0.3f)
        }
    }
}

@Composable
fun SliderRow(label:String, initial:Float) {
    var v by remember(label) { mutableFloatStateOf(initial) }
    Column {
        Row { Text(label, Modifier.weight(1f), fontSize=13.sp); Text("${(v*100).toInt()}%", color=muted,fontSize=12.sp) }
        Slider(value=v,onValueChange={v=it}, colors=SliderDefaults.colors(thumbColor=green,activeTrackColor=green))
    }
}

@Composable
fun DownloadPage() {
    Panel {
        Text("OYUN PAKETİ",color=green,fontWeight=FontWeight.Bold,fontSize=18.sp)
        Spacer(Modifier.height(8.dp))
        Text("TR PORT oyun verisi indirme arayüzü hazır. Gerçek indirme için lisanslı kaynak, manifest, checksum ve erişilebilir sunucu gerekir.",color=muted)
        Spacer(Modifier.height(12.dp))
        listOf("7 GB • Minimal","16 GB • Temel","24 GB • Dengeli","43 GB • Geniş","72 GB • Yüksek kalite").forEach { label ->
            OutlinedButton(onClick={},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.outlinedButtonColors(contentColor=Color.White)) {
                Text(label)
            }
        }
        Text("Bu paket düğmeleri şimdilik etkin değil; sahte dosya indirmesi yapmaz.",color=Color(0xFFFFC66D),fontSize=12.sp)
    }
}

@Composable
fun GamepadPage() {
    Panel {
        Text("KONTROL DÜZENİ",color=green,fontWeight=FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("Dokunmatik kontrol yerleşimi prototipi",color=muted)
        Spacer(Modifier.height(12.dp))
        Box(Modifier.fillMaxWidth().height(230.dp).background(Color(0xFF0D1510),RoundedCornerShape(16.dp))) {
            Box(Modifier.align(Alignment.CenterStart).padding(18.dp).size(110.dp).background(Color(0x553CFF7D),RoundedCornerShape(100)),contentAlignment=Alignment.Center) { Text("JOYSTICK",fontSize=12.sp,color=green) }
            Column(Modifier.align(Alignment.CenterEnd).padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                listOf("A","B","X","Y").forEach { Text(it,Modifier.background(Color(0x553CFF7D),RoundedCornerShape(50)).padding(12.dp),color=green) }
            }
            Text("KAMERA",Modifier.align(Alignment.BottomCenter).padding(bottom=12.dp),color=muted,fontSize=11.sp)
        }
        Spacer(Modifier.height(12.dp))
        SliderRow("Tuş boyutu",0.65f)
        SliderRow("Şeffaflık",0.75f)
        Text("Bluetooth gamepad bağlantısı ve tuş eşlemesi bu prototipte henüz entegre değil.",color=muted,fontSize=12.sp)
    }
}

@Composable
fun SettingsPage(renderer:String,setRenderer:(String)->Unit,low:Boolean,setLow:(Boolean)->Unit) {
    Column(verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Panel {
            Text("RENDER API",color=green,fontWeight=FontWeight.Bold)
            listOf("Otomatik","Vulkan","OpenGL ES").forEach { r ->
                Row(verticalAlignment=Alignment.CenterVertically) {
                    RadioButton(selected=renderer==r,onClick={setRenderer(r)},colors=RadioButtonDefaults.colors(selectedColor=green))
                    Text(r)
                }
            }
            Text("Turnip/DXVK seçimi yalnız uyumlu oyun çalışma ortamı ve GPU sürücüleri bulunduğunda yapılabilir.",color=muted,fontSize=12.sp)
        }
        Panel {
            Text("GÜVENLİK & KARARLILIK",color=green,fontWeight=FontWeight.Bold)
            InfoRow("Hata kaydı","Bu prototipte yerel")
            InfoRow("Dosya doğrulama","Kaynak eklenmedi")
            InfoRow("Crash koruma","Uygulama katmanı")
            InfoRow("Isı izleme","API erişimi sınırlı")
        }
        Panel {
            Text("DÜŞÜK CİHAZ MODU",fontWeight=FontWeight.Bold)
            Switch(checked=low,onCheckedChange=setLow,colors=SwitchDefaults.colors(checkedThumbColor=Color.Black,checkedTrackColor=green))
        }
    }
}

@Composable
fun BottomNav(current:String, onSelect:(String)->Unit) {
    val items=listOf("Ana Sayfa","İndirme","Grafik","Gamepad","Ayarlar")
    NavigationBar(containerColor=Color(0xFF101612)) {
        items.forEach { item ->
            NavigationBarItem(selected=current==item,onClick={onSelect(item)},
                icon={Text(when(item){"Ana Sayfa"->"⌂";"İndirme"->"↓";"Grafik"->"▧";"Gamepad"->"⌘";else->"⚙"},fontSize=18.sp)},
                label={Text(item,fontSize=9.sp)},colors=NavigationBarItemDefaults.colors(selectedIconColor=green,selectedTextColor=green,indicatorColor=Color(0xFF20382A),unselectedTextColor=muted))
        }
    }
}

@Composable
fun Panel(content:@Composable ColumnScope.()->Unit) {
    Column(Modifier.fillMaxWidth().background(panel,RoundedCornerShape(18.dp)).padding(14.dp),verticalArrangement=Arrangement.spacedBy(6.dp),content=content)
}
@Composable
fun InfoRow(label:String,value:String) {
    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
        Text(label,color=muted,fontSize=12.sp,modifier=Modifier.weight(1f))
        Text(value,color=Color.White,fontSize=12.sp,textAlign=TextAlign.End)
    }
}
@Composable
fun ActionCard(title:String,subtitle:String,modifier:Modifier=Modifier,onClick:()->Unit) {
    Card(onClick=onClick,modifier=modifier.height(96.dp),colors=CardDefaults.cardColors(containerColor=panel),shape=RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.Center) {
            Text(title,color=green,fontWeight=FontWeight.Bold,fontSize=13.sp)
            Spacer(Modifier.height(4.dp))
            Text(subtitle,color=muted,fontSize=10.sp)
        }
    }
}
