# TR PORT Android Prototype

Android Studio project for a mobile-first GTA V companion/launcher interface prototype.

## Included
- Compose mobile UI (portrait)
- Navigation tabs
- Graphics profile and FPS target settings
- Resolution selector
- Low-device toggle
- Basic device/system information screen
- Settings persisted via SharedPreferences
- Download and gamepad screens marked as prototype/not implemented

## Important
This project does **not** contain GTA V files, a game engine, or an actual GTA V Android port.
No real FPS measurement, game downloading, Bluetooth gamepad mapping, Vulkan/DXVK/Turnip integration,
thermal monitoring, or game runtime is implemented yet. Buttons are intentionally not presented
as completed game-launch functionality.

## Build
1. Open the folder in Android Studio.
2. Allow Gradle sync.
3. Connect an Android phone or use an emulator.
4. Run the `app` configuration.

Build an APK: Build > Build Bundle(s) / APK(s) > Build APK(s).

This is a starter project, not a tested production release. Device testing and debugging are required.
