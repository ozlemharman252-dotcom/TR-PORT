package com.example.buildtemplate;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TextView text = new TextView(this);
        text.setText("Android project builds successfully!");
        text.setTextSize(22);
        text.setGravity(Gravity.CENTER);
        setContentView(text);
    }
}
