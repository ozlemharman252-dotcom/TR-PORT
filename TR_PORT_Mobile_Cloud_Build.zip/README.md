# TR PORT Android Project (v1.0 prototype)

Bu bir Android Studio proje iskeletidir; henüz derlenmiş APK değildir.

## Açma ve APK üretme
1. Android Studio'yu kurun.
2. Bu klasörü Android Studio ile açın.
3. Gradle senkronizasyonunu tamamlayın.
4. `Build > Build Bundle(s) / APK(s) > Build APK(s)` seçin.
5. APK genellikle `app/build/outputs/apk/debug/app-debug.apk` konumunda oluşur.

## Önemli sınırlar
- Bu sürüm launcher/arayüz prototipidir; GTA V oyun dosyalarını içermez.
- FPS değerleri hedef tercihidir, gerçek FPS garantisi değildir.
- Turnip/DXVK seçimi şimdilik görsel prototiptir; sürücü yüklemez/değiştirmez.
- Model menüsü oyun motoru/mod entegrasyonu olmadan oyundaki karakteri değiştiremez.
- Cihaz analizi sınırlı Android WebView bilgileriyle yapılır; kesin benchmark değildir.
- 2/7/16/24/43/72 GB seçenekleri paket taslağıdır; indirilebilir oyun içeriği yoktur.

## Teknik
- Kotlin Android Activity + yerel HTML arayüzü
- minSdk 23, compileSdk 35


## APK'yı sadece Android telefonla üretme (bulut derleme)
Bu projede GitHub Actions iş akışı bulunur. Bilgisayar gerekmez; derleme GitHub sunucularında yapılır.

1. GitHub hesabı açın ve tarayıcıdan yeni, public veya private bir repository oluşturun.
2. ZIP'i telefonda çıkarın. GitHub web sitesinde repository içinde **Add file > Upload files** ile klasörün içindeki dosyaları (`.github` klasörü dahil) yükleyip commit edin.
3. Repository'de **Actions** sekmesine girin. `Build TR PORT APK` iş akışını açın.
4. `Run workflow` düğmesine basın (push yaptıysanız otomatik de çalışır).
5. İşlem yeşil tik ile tamamlanınca çalıştırma sayfasının altındaki **Artifacts** bölümünden `TR-PORT-debug-apk` dosyasını indirin.
6. İnen artifact ZIP'ini açın; içindeki `app-debug.apk` dosyasını telefona kurun.

Not: GitHub hesabı gerekir. APK debug/test sürümüdür; yayınlamak için imzalı release APK ayrıca hazırlanmalıdır.
